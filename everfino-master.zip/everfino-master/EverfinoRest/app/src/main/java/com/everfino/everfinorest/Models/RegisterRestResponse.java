package com.everfino.everfinorest.Models;

public class RegisterRestResponse {
    public int restid;
    public String restname;

    public int getRestid() {
        return restid;
    }

    public void setRestid(int restid) {
        this.restid = restid;
    }

    public String getRestname() {
        return restname;
    }

    public void setRestname(String restname) {
        this.restname = restname;
    }
}
